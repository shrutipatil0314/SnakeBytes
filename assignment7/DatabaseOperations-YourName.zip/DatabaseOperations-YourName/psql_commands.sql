-- psql_commands.sql
-- The same steps done directly in psql instead of Python.
-- Start psql with:   psql -U postgres -h localhost -p 5432

-- ---------- Creating and dropping databases ----------
CREATE DATABASE student_db;      -- the one used in this assignment
CREATE DATABASE test_db;         -- a throwaway database just to practise dropping
\l                               -- list all databases

DROP DATABASE test_db;           -- can't drop a database you're connected to
\l                               -- test_db should be gone now

-- ---------- Creating a table and inserting records ----------
\c student_db                    -- connect to student_db

CREATE TABLE IF NOT EXISTS students (
    student_id SERIAL PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    age        INT,
    course     VARCHAR(50),
    marks      NUMERIC(5, 2)
);

\dt                              -- list tables
\d students                      -- show the table structure

INSERT INTO students (name, age, course, marks) VALUES ('Alice', 20, 'Python', 85.5);
INSERT INTO students (name, age, course, marks) VALUES ('Bob', 22, 'Data Science', 78.0);
INSERT INTO students (name, age, course, marks) VALUES ('Charlie', 21, 'Python', 92.25);

-- ---------- SELECT with WHERE ----------
SELECT * FROM students;
SELECT * FROM students WHERE marks > 80;
SELECT name, marks FROM students WHERE course = 'Python';

-- ---------- TRUNCATE ----------
TRUNCATE TABLE students RESTART IDENTITY;
SELECT * FROM students;          -- should return 0 rows

\q
