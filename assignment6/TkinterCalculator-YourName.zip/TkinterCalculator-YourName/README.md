# Tkinter Calculator

This is my calculator app for the Module 10 Tkinter assignment. It opens a small window where you can click buttons to do basic maths, kind of like the calculator on a phone.

## What it can do

- Add, subtract, multiply and divide
- Show what you type and the answer in the box at the top
- Clear everything with the `clear` button
- Show "Cannot divide by 0" if you try to divide by zero, and "Error" if the expression doesn't make sense (like `5+` with nothing after it)

## How to run it

You need Python 3 installed. Tkinter comes with it, so there is nothing else to download.

Open a terminal in this folder and type:

```
python tkinter_calculator.py
```

On Mac or Linux you might need `python3` instead of `python`.

## How to use it

1. Click the number buttons and an operator to build your sum, for example `1`, `2`, `*`, `3`.
2. Press `=` to see the answer (that one gives `36`).
3. Press `clear` to start again.

The box at the top is read-only, so you can't type into it from the keyboard. You have to use the buttons.

## How I built it

- **Window and Entry:** `tk.Tk()` makes the window, and an `Entry` widget is the display.
- **Buttons:** I made them in a loop instead of writing each one by hand, and placed them with `grid()` so they line up in rows and columns like the screenshot in the assignment.
- **lambda:** each button needs to send its own value (like "7") to the `press()` function. Using `lambda` was the way to do that, as shown in the course notes.
- **Calculating:** when `=` is pressed, the text in the display is worked out with Python's `eval()`. I know `eval()` isn't a good idea in a real app, but the assignment hint says it's fine here, and the only way to enter text is through the buttons anyway.
- **Errors:** `try` / `except` catches divide by zero and bad expressions so the program doesn't crash.

## Things I'd add with more time

- A decimal point button
- Keyboard support
- A backspace button

## Files

- `tkinter_calculator.py`: the whole program
- `README.md`: this file
