# Django REST API: Blog Posts

This is my Django REST Framework assignment. It's a blog post API where every user has their own posts. You log in, and then you can create, read, update and delete only your own posts. The list endpoint also supports searching, filtering by date, ordering by ID and pagination (5 posts per page).

## What I used

| Part | Technology |
|------|------------|
| Backend | Django |
| REST API | Django REST Framework (DRF) |
| Filtering | django-filter |
| Database | SQLite3 (the default one) |
| Authentication | Session login (browsable API) + Token login |
| Language | Python 3 |

## Setting it up

You need Python 3 installed. Open a terminal in the `blog` folder (the one that has `manage.py`).

**1. Make a virtual environment and turn it on**

```
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac / Linux
```

**2. Install the packages** (the `requirements.txt` file is one folder up)

```
pip install -r ../requirements.txt
```

**3. Create the database tables**

```
python manage.py makemigrations
python manage.py migrate
```

This creates the `db.sqlite3` file. If `makemigrations` says "No changes detected", that's fine, the migration is already included.

**4. Add some demo data** (optional, but it makes testing much easier)

```
python manage.py seed_demo_data
```

This creates three users and some posts. Alice gets 8 posts, so you can see pagination working right away.

| Username | Password | Notes |
|----------|----------|-------|
| `admin` | `admin@12345` | superuser, can open `/admin/` |
| `alice` | `alice@12345` | 8 posts |
| `bob` | `bob@12345` | 3 posts |

**5. Start the server**

```
python manage.py runserver
```

Then open **http://127.0.0.1:8000/**. It redirects to the posts list.

## Logging in

- **In the browser:** go to http://127.0.0.1:8000/api-auth/login/ and use one of the accounts above. After logging in you'll land on the posts list and the browsable API will show a form for creating posts.
- **With a token (Postman, curl):** send a POST request to `/api-token-auth/` with a username and password, and you get a token back. Then add this header to every request:
  ```
  Authorization: Token <your token>
  ```
  Example:
  ```
  curl -X POST http://127.0.0.1:8000/api-token-auth/ -d "username=alice&password=alice@12345"
  curl http://127.0.0.1:8000/api/posts/ -H "Authorization: Token <your token>"
  ```

Without logging in, every endpoint refuses the request (403 in the browser, since session login is checked first).

## The endpoints

| Method | URL | What it does |
|--------|-----|--------------|
| GET | `/api/posts/` | List my posts (5 per page) |
| POST | `/api/posts/` | Create a post |
| GET | `/api/posts/<id>/` | Get one of my posts |
| PUT / PATCH | `/api/posts/<id>/` | Update one of my posts |
| DELETE | `/api/posts/<id>/` | Delete one of my posts |

To create a post, send JSON like this. The owner is filled in automatically from whoever is logged in:

```json
{
  "title": "My first post",
  "content": "Hello from the API!"
}
```

### Searching, filtering, ordering and pages

| What | Example |
|------|---------|
| Search in title and content | `/api/posts/?search=django` |
| Posts created on one day | `/api/posts/?created_date=2026-11-14` |
| Posts created on or after a day | `/api/posts/?created_after=2026-11-10` |
| Posts created on or before a day | `/api/posts/?created_before=2026-11-14` |
| Order by ID, lowest first | `/api/posts/?ordering=id` |
| Order by ID, highest first | `/api/posts/?ordering=-id` |
| Go to page 2 | `/api/posts/?page=2` |

You can mix them, for example `/api/posts/?search=django&ordering=-id&page=1`. Dates use the `YYYY-MM-DD` format.

The list comes back like this:

```json
{
  "count": 8,
  "next": "http://127.0.0.1:8000/api/posts/?page=2",
  "previous": null,
  "results": [
    {
      "id": 1,
      "owner": "alice",
      "title": "Getting started with Django (alice)",
      "content": "Django is a high-level Python web framework.",
      "created_at": "2026-11-14T22:10:00+05:30",
      "updated_at": "2026-11-14T22:10:00+05:30"
    }
  ]
}
```

## How I made sure users only see their own posts

I did it in two places:

1. **The queryset.** Both views only look at `Post.objects.filter(owner=request.user)`. So if Alice asks for one of Bob's posts, it simply isn't there and she gets a **404**.
2. **A custom permission.** `IsOwner` in `permissions.py` checks `obj.owner == request.user` for single posts, as a second layer.

## Project structure

```
DjangoRestAPI-YourName/
├── README.md
├── requirements.txt
└── blog/
    ├── manage.py
    ├── db.sqlite3
    ├── blog/                  # project settings
    │   ├── __init__.py
    │   ├── settings.py
    │   ├── urls.py
    │   ├── wsgi.py
    │   └── asgi.py
    └── helloworld/            # the app
        ├── migrations/
        ├── management/commands/seed_demo_data.py
        ├── __init__.py
        ├── admin.py
        ├── apps.py
        ├── models.py
        ├── views.py
        ├── serializers.py
        ├── permissions.py
        ├── filters.py
        └── tests.py
```

What each important file does:

- `models.py`: the `Post` model (owner, title, content, created_at, updated_at)
- `serializers.py`: turns posts into JSON and back; the owner is shown as a username and can't be set by the client
- `views.py`: the list/create view and the detail view, with search, filter and ordering switched on
- `permissions.py`: the `IsOwner` permission
- `filters.py`: the creation date filters
- `settings.py`: DRF setup (authentication, login required, 5 per page, JSON)

## Running the tests

I wrote tests for the main requirements: login required, tokens, owner-only access, pagination, search, ordering and the date filters.

```
python manage.py test
```

## Things I learned / ran into

- `created_at` is set automatically, so for the demo data I update it after creating each post. That gives the posts different dates and lets the date filter show something.
- The browsable API page is just a nicer view of the same JSON. Add `?format=json` to any URL to see the raw JSON.
- If you see `ModuleNotFoundError: No module named 'rest_framework'`, the virtual environment isn't active or the packages weren't installed (step 2).
- If you see `no such table`, run `python manage.py migrate` (step 3).
