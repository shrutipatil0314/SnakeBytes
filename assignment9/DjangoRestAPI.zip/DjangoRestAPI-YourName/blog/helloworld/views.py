from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, generics, permissions

from .filters import PostFilter
from .models import Post
from .permissions import IsOwner
from .serializers import PostSerializer


class OwnPostsMixin:
    """Shared by both views: a user only ever sees their own posts."""

    serializer_class = PostSerializer

    def get_queryset(self):
        user = self.request.user
        if not user.is_authenticated:
            return Post.objects.none()
        return Post.objects.filter(owner=user)


class PostListCreateView(OwnPostsMixin, generics.ListCreateAPIView):
    """
    GET  /api/posts/   -> list my posts (5 per page)
    POST /api/posts/   -> create a post (owner is set automatically)

    Extra query parameters:
        ?search=word                 search in title and content
        ?ordering=id or ?ordering=-id
        ?created_date=YYYY-MM-DD     (see filters.py for the others)
        ?page=2
    """

    permission_classes = [permissions.IsAuthenticated]

    filter_backends = [
        DjangoFilterBackend,
        filters.SearchFilter,
        filters.OrderingFilter,
    ]
    filterset_class = PostFilter
    search_fields = ["title", "content"]
    ordering_fields = ["id"]
    ordering = ["id"]

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class PostDetailView(OwnPostsMixin, generics.RetrieveUpdateDestroyAPIView):
    """
    GET / PUT / PATCH / DELETE  /api/posts/<id>/

    The queryset only contains my own posts, so asking for somebody else's
    post gives a 404. IsOwner is a second layer of protection.
    """

    permission_classes = [permissions.IsAuthenticated, IsOwner]
