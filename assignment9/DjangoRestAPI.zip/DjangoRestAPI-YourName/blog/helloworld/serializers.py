from rest_framework import serializers

from .models import Post


class PostSerializer(serializers.ModelSerializer):
    # Show the username instead of the user id, and don't let clients set it
    owner = serializers.ReadOnlyField(source="owner.username")

    class Meta:
        model = Post
        fields = ["id", "owner", "title", "content", "created_at", "updated_at"]
        read_only_fields = ["id", "owner", "created_at", "updated_at"]
