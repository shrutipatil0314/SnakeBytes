from datetime import timedelta

from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase

from .models import Post

User = get_user_model()


class BlogApiTests(APITestCase):
    def setUp(self):
        self.alice = User.objects.create_user("alice", password="alice@12345")
        self.bob = User.objects.create_user("bob", password="bob@12345")
        self.list_url = reverse("post-list")

    def make_post(self, owner, title="A title", content="Some content"):
        return Post.objects.create(owner=owner, title=title, content=content)

    def detail_url(self, post):
        return reverse("post-detail", args=[post.pk])

    # ---------- authentication ----------
    def test_anonymous_user_is_rejected(self):
        response = self.client.get(self.list_url)
        self.assertIn(response.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))

    def test_token_authentication_works(self):
        token = Token.objects.create(user=self.alice)
        self.client.credentials(HTTP_AUTHORIZATION=f"Token {token.key}")
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_token_endpoint_returns_a_token(self):
        response = self.client.post(
            reverse("api-token-auth"),
            {"username": "alice", "password": "alice@12345"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("token", response.data)

    # ---------- create / read ----------
    def test_create_post_sets_owner_automatically(self):
        self.client.force_authenticate(self.alice)
        response = self.client.post(
            self.list_url, {"title": "Hello", "content": "World"}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["owner"], "alice")
        self.assertEqual(Post.objects.get().owner, self.alice)

    def test_client_cannot_choose_the_owner(self):
        self.client.force_authenticate(self.alice)
        response = self.client.post(
            self.list_url,
            {"title": "Hello", "content": "World", "owner": "bob"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["owner"], "alice")

    def test_list_only_shows_my_posts(self):
        self.make_post(self.alice, "Alice post")
        self.make_post(self.bob, "Bob post")
        self.client.force_authenticate(self.alice)
        response = self.client.get(self.list_url)
        titles = [p["title"] for p in response.data["results"]]
        self.assertEqual(titles, ["Alice post"])

    def test_responses_are_json(self):
        self.client.force_authenticate(self.alice)
        response = self.client.get(self.list_url, HTTP_ACCEPT="application/json")
        self.assertEqual(response["Content-Type"], "application/json")

    # ---------- ownership ----------
    def test_cannot_see_someone_elses_post(self):
        post = self.make_post(self.bob)
        self.client.force_authenticate(self.alice)
        response = self.client.get(self.detail_url(post))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_cannot_update_someone_elses_post(self):
        post = self.make_post(self.bob, title="Original")
        self.client.force_authenticate(self.alice)
        response = self.client.patch(self.detail_url(post), {"title": "Hacked"}, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        post.refresh_from_db()
        self.assertEqual(post.title, "Original")

    def test_cannot_delete_someone_elses_post(self):
        post = self.make_post(self.bob)
        self.client.force_authenticate(self.alice)
        response = self.client.delete(self.detail_url(post))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertTrue(Post.objects.filter(pk=post.pk).exists())

    def test_owner_can_update_and_delete(self):
        post = self.make_post(self.alice, title="Old title")
        self.client.force_authenticate(self.alice)

        response = self.client.put(
            self.detail_url(post), {"title": "New title", "content": "New content"}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "New title")

        response = self.client.patch(self.detail_url(post), {"content": "Patched"}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["content"], "Patched")

        response = self.client.delete(self.detail_url(post))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Post.objects.filter(pk=post.pk).exists())

    # ---------- pagination ----------
    def test_pagination_is_five_per_page(self):
        for i in range(7):
            self.make_post(self.alice, title=f"Post {i}")
        self.client.force_authenticate(self.alice)

        page1 = self.client.get(self.list_url)
        self.assertEqual(page1.data["count"], 7)
        self.assertEqual(len(page1.data["results"]), 5)
        self.assertIsNotNone(page1.data["next"])

        page2 = self.client.get(self.list_url, {"page": 2})
        self.assertEqual(len(page2.data["results"]), 2)
        self.assertIsNone(page2.data["next"])

    # ---------- searching ----------
    def test_search_in_title_and_content(self):
        self.make_post(self.alice, title="Django tips", content="nothing special")
        self.make_post(self.alice, title="Cooking", content="a django-style pizza")
        self.make_post(self.alice, title="Gardening", content="roses")
        self.client.force_authenticate(self.alice)

        response = self.client.get(self.list_url, {"search": "django"})
        titles = sorted(p["title"] for p in response.data["results"])
        self.assertEqual(titles, ["Cooking", "Django tips"])

    # ---------- ordering ----------
    def test_ordering_by_id(self):
        first = self.make_post(self.alice, title="first")
        second = self.make_post(self.alice, title="second")
        self.client.force_authenticate(self.alice)

        asc = self.client.get(self.list_url, {"ordering": "id"})
        self.assertEqual([p["id"] for p in asc.data["results"]], [first.id, second.id])

        desc = self.client.get(self.list_url, {"ordering": "-id"})
        self.assertEqual([p["id"] for p in desc.data["results"]], [second.id, first.id])

    # ---------- filtering by creation date ----------
    def test_filter_by_creation_date(self):
        old_post = self.make_post(self.alice, title="old")
        new_post = self.make_post(self.alice, title="new")

        old_moment = timezone.now() - timedelta(days=10)
        Post.objects.filter(pk=old_post.pk).update(created_at=old_moment)

        old_day = timezone.localtime(old_moment).date().isoformat()
        today = timezone.localdate().isoformat()
        self.client.force_authenticate(self.alice)

        def ids(params):
            response = self.client.get(self.list_url, params)
            return [p["id"] for p in response.data["results"]]

        self.assertEqual(ids({"created_date": old_day}), [old_post.id])
        self.assertEqual(ids({"created_date": today}), [new_post.id])
        self.assertEqual(ids({"created_after": today}), [new_post.id])
        self.assertEqual(ids({"created_before": old_day}), [old_post.id])
