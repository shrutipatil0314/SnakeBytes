from rest_framework import permissions


class IsOwner(permissions.BasePermission):
    """
    Object-level permission: only the owner of a post can read, edit or
    delete it. Nobody else gets in, not even for read-only requests.
    """

    def has_object_permission(self, request, view, obj):
        return obj.owner == request.user
