import django_filters

from .models import Post


class PostFilter(django_filters.FilterSet):
    """
    Filter posts by creation date. Dates use the format YYYY-MM-DD.

        ?created_date=2026-11-14      posts created on that exact day
        ?created_after=2026-11-01     posts created on or after that day
        ?created_before=2026-11-14    posts created on or before that day
    """

    created_date = django_filters.DateFilter(field_name="created_at", lookup_expr="date")
    created_after = django_filters.DateFilter(field_name="created_at", lookup_expr="date__gte")
    created_before = django_filters.DateFilter(field_name="created_at", lookup_expr="date__lte")

    class Meta:
        model = Post
        fields = []
