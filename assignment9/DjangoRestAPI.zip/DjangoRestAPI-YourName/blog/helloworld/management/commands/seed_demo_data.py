"""
Fills the database with demo users and posts so the API can be tried out
straight away.

    python manage.py seed_demo_data

It is safe to run more than once: users are reused and posts are only
created for users that don't have any yet.
"""

from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone
from rest_framework.authtoken.models import Token

from helloworld.models import Post

User = get_user_model()

DEMO_USERS = [
    # username, password, is_superuser, number of posts
    ("admin", "admin@12345", True, 0),
    ("alice", "alice@12345", False, 8),
    ("bob", "bob@12345", False, 3),
]

TOPICS = [
    ("Getting started with Django", "Django is a high-level Python web framework."),
    ("Why I like REST APIs", "A REST API lets different apps talk to each other using JSON."),
    ("Notes on authentication", "Token and session authentication solve different problems."),
    ("Filtering and searching", "Query parameters make an API far more useful."),
    ("Pagination explained", "Returning everything at once does not scale, so we split it into pages."),
    ("Python tips for beginners", "Use virtual environments and read error messages carefully."),
    ("Weekend project ideas", "Build a small blog, a to-do list or a weather app."),
    ("Learning to test code", "Tests catch bugs before your users do."),
]


class Command(BaseCommand):
    help = "Create demo users, tokens and sample blog posts."

    def handle(self, *args, **options):
        for username, password, is_superuser, post_count in DEMO_USERS:
            user, created = User.objects.get_or_create(username=username)
            user.set_password(password)
            user.email = f"{username}@example.com"
            if is_superuser:
                user.is_staff = True
                user.is_superuser = True
            user.save()

            token, _ = Token.objects.get_or_create(user=user)
            self.stdout.write(
                f"{'Created' if created else 'Updated'} user '{username}' "
                f"(password: {password})  token: {token.key}"
            )

            if post_count and not Post.objects.filter(owner=user).exists():
                self._create_posts(user, post_count)

        self.stdout.write(self.style.SUCCESS("Demo data is ready."))

    def _create_posts(self, user, count):
        now = timezone.now()
        for i in range(count):
            title, content = TOPICS[i % len(TOPICS)]
            post = Post.objects.create(
                owner=user,
                title=f"{title} ({user.username})",
                content=content,
            )
            # created_at is set automatically, so push it back a few days
            # afterwards to give the date filter something to work with
            Post.objects.filter(pk=post.pk).update(created_at=now - timedelta(days=i))
        self.stdout.write(f"  added {count} posts for '{user.username}'")
