"""
URL configuration for the blog project.

    /                    -> redirects to the posts list
    /admin/              -> Django admin
    /api/posts/          -> list + create posts
    /api/posts/<id>/     -> retrieve + update + delete one post
    /api-auth/login/     -> login page for the browsable API (session auth)
    /api-token-auth/     -> POST username + password, get back a token
"""

from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from rest_framework.authtoken.views import obtain_auth_token

from helloworld.views import PostListCreateView, PostDetailView

urlpatterns = [
    path("", RedirectView.as_view(url="/api/posts/", permanent=False)),
    path("admin/", admin.site.urls),
    path("api/posts/", PostListCreateView.as_view(), name="post-list"),
    path("api/posts/<int:pk>/", PostDetailView.as_view(), name="post-detail"),
    path("api-auth/", include("rest_framework.urls")),
    path("api-token-auth/", obtain_auth_token, name="api-token-auth"),
]
