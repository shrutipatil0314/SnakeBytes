# Assignment 5: Module 6 - Data Structures and Strings in Python

## Contents

| File | Description |
|------|-------------|
| `task1_student_marks.py` | Task 1: Dictionary of student marks |
| `task2_list_slicing.py` | Task 2: Demonstrate list slicing |
| `README.md` | This file |

## Task 1: Create a Dictionary of Student Marks

Creates a dictionary where student names are keys and their marks are values. The program asks the user for a student's name, then displays the marks if the student exists, or "Student not found." otherwise.

**Run:**
```
python task1_student_marks.py
```

**Sample output:**
```
Enter the student's name: Alice
Alice's marks: 85
```
```
Enter the student's name: John
Student not found.
```

## Task 2: Demonstrate List Slicing

Creates a list of numbers from 1 to 10, extracts the first five elements using slicing, reverses them, and prints the original, extracted, and reversed lists.

**Run:**
```
python task2_list_slicing.py
```

**Sample output:**
```
Original list: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Extracted first five elements: [1, 2, 3, 4, 5]
Reversed extracted elements: [5, 4, 3, 2, 1]
```

## Requirements

- Python 3.6 or higher (uses f-strings)
- No external libraries needed
