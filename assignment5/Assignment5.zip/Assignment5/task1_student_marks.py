# Task 1: Create a Dictionary of Student Marks

# Dictionary with student names as keys and marks as values
students = {
    "Alice": 85,
    "Bob": 78,
    "Charlie": 92,
    "Diana": 88
}

# Ask the user to input a student's name
name = input("Enter the student's name: ")

# Retrieve and display marks, or show a message if not found
if name in students:
    print(f"{name}'s marks: {students[name]}")
else:
    print("Student not found.")
